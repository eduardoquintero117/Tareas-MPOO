//
//  ViewController.swift
//  tarea2.2
//
//  Created by Eduardo Quintero on 06/03/18.
//  Copyright © 2018 New X. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider1: UISlider!
    
    @IBOutlet weak var letrero: UILabel!
    
    @IBAction func slider1(_ sender: UISlider) {
        let valor = Int (slider1.value * 100)
        let cadena = "\(valor)%"
        letrero.text = cadena
        
        switch valor {
        case 0...25:
            view.backgroundColor = UIColor(displayP3Red: 0.0, green:CGFloat(2 * Float(slider1.value )), blue: 0.7, alpha:CGFloat(0.3 + Float(slider1.value )) )
        case 26...50:
            view.backgroundColor = UIColor(displayP3Red: 0.0, green:0.5, blue: 0.7, alpha: CGFloat(0.4 + Float(slider1.value )) )
        case 51...75:
            view.backgroundColor = UIColor(displayP3Red: 0.0, green:0.5, blue: 0.7, alpha: CGFloat(1.6 - Float(slider1.value )) )
            
            
        default:
            view.backgroundColor = UIColor(displayP3Red: 0.0, green:CGFloat(2.0 - (2 * Float(slider1.value ))), blue: 0.7, alpha:CGFloat(1.4 - Float(slider1.value )) )
        }

    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

