//
//  ViewController.swift
//  ejemplo1.3
//
//  Created by Eduardo Quintero on 01/03/18.
//  Copyright © 2018 New X. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var vista: UILabel!
    
    
    @IBOutlet weak var primerNum: UITextField!
    
    @IBOutlet weak var segudoNum: UITextField!
    
    @IBAction func suma(_ sender: Any) {
        
        let num = primerNum.text
        var numero1 = 0
        var numero2 = 0
        var suma = 0
        
    
        if let num1 = Int(num!) {
            
              numero1 = num1
            
            
            let num1 = segudoNum.text
            
            if let num2 = Int(num1!) {
                
                numero2 = num2
                suma = numero1 + numero2
                
                vista.text = "Resultado \(suma)"
                
            }else {
                
                vista.text = "El segundo no es un numero "
            }
            
        }else {
            vista.text = "El primer no es un numero"
            
             }
        
        
            
       }
    
    
    @IBAction func resta(_ sender: Any) {
        
        
        
        let num = primerNum.text
        var numero1 = 0
        var numero2 = 0
        var resta = 0
        
        
        if let num1 = Int(num!) {
            
            numero1 = num1
            
            
            let num1 = segudoNum.text
            
            if let num2 = Int(num1!) {
                
                numero2 = num2
                resta = numero1 - numero2
                
                vista.text = "Resultado \(resta)"
                
            }else {
                
                vista.text = "El segundo numero es un caracter"
            }
            
        }else {
            vista.text = "El primer numero es un caracter"
            
        }
        
        
        
        
    }
    
//____------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

